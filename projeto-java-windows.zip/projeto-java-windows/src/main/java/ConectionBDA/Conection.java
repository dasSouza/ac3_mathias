//package ConectionBDA;
//
//import org.apache.commons.dbcp2.BasicDataSource;
//
//public class Conection {
//    private BasicDataSource dataSource;
//
//        public Conection() {
//            this.dataSource = new BasicDataSource();
//            dataSource.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//            dataSource.setUrl("jdbc:sqlserver://grupo-8.database.windows.net;" +
//                    "databaseName=kcode;");
//            dataSource.setUsername("grupo-8");
//            dataSource.setPassword("#Gfkcode8");
//        }
//
//        public BasicDataSource getDataSource() {
//            return dataSource;
//        }
//
//    }
