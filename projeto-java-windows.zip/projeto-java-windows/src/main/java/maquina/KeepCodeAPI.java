package maquina;

import empresa.CompanyDAO;
//import DAO.UsuariosDAO;
import maquina.processos.GetAllProcess;
import maquina.processos.ProcessIDE;
import usuario.Usuario;
import java.io.IOException;
import log.GerandoLog;
import maquina.processos.*;

public class KeepCodeAPI {

    public KeepCodeAPI(Usuario user) {
    }

    public void chamandoProcessos(Usuario usuario) throws IOException {

        GerandoLog gerarLog = new GerandoLog();
        try {
            gerarLog.gravarLog("\n chamando todos os processos");

        } catch (IOException e) {
            gerarLog.gravarLog(String.format("\n %s", e));

        }

        GetAllProcess getAllDatesProcess = new GetAllProcess(usuario);
        ProcessIDE processosIDE = new ProcessIDE();
        ProcessMaqDAO maqDao = new ProcessMaqDAO(usuario);

        getAllDatesProcess.getNamePc();
        getAllDatesProcess.getDiscoTotal();
        getAllDatesProcess.getCpuNome();
        getAllDatesProcess.memoriaTotal();

        getAllDatesProcess.insertDatesMaquina(usuario);
        
//        maqDao.maquinaProcess(maqDao, usuario);
//        processosIDE.getFkIdMaquina(usuario);

        processosIDE.putAllNameIde();
        processosIDE.getIdeName();
        processosIDE.getIdeCpu();
        processosIDE.getIdeRam();
        processosIDE.getIdeDisco();
        processosIDE.insertIdeProcess();

//        processosIDE.showAll();
    }

}
