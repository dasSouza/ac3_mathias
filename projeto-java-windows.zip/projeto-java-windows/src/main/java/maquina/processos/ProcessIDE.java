package maquina.processos;

import maquina.processos.ProcessIdeDAO;
import usuario.Usuario;
import com.github.britooo.looca.api.core.Looca;
import com.github.britooo.looca.api.group.processos.Processo;
import java.io.IOException;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.xml.transform.Templates;
import jdbc.Conexao;
import log.GerandoLog;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

public class ProcessIDE extends ProcessDatas {

    Looca looca = new Looca();
//    ProcessIdeDAO processIdeDAO = new ProcessIdeDAO(super.fk_id_maquina);
    ProcessDatas processDatas = new ProcessDatas();
    Conexao con = new Conexao();
    JdbcTemplate template = new JdbcTemplate(con.getBanco());
    List<Processo> processoList = looca.getGrupoDeProcessos().getProcessos();
    List<String> nomesIde = new ArrayList<>();

    public void putAllNameIde() {
        nomesIde.add("Code");
        nomesIde.add("netbeans64");
        nomesIde.add("pycharm64");
        nomesIde.add("Xcode");
        nomesIde.add("idea64");
        nomesIde.add("studio64");
        nomesIde.add("eclipse");
        nomesIde.add("devenv");
        nomesIde.add("phpstorm64");
        nomesIde.add("phpstorm32");
        nomesIde.add("webstorm64");
        nomesIde.add("webstorm32");
    }

    public void getIdeName() {
        for (Processo processo : processoList) {
            for (int i = 0; i < nomesIde.size(); i++) {
                if (processo.getNome().equals(nomesIde.get(i))) {
                    processDatas.setUs_ide_nome_processo(nomesIde.get(i));
                    super.valoresNomeIDE.add(processDatas.getUs_ide_nome_processo());
                }
            }
        }
    }

    public void getIdeCpu() {
        for (Processo processo : processoList) {
            for (int i = 0; i < nomesIde.size(); i++) {
                if (processo.getNome().equals(nomesIde.get(i))) {
                    processDatas.setUs_ide_cpu(processo.getUsoCpu().floatValue());
                    super.valoresCpuIDE.add(processDatas.getUs_ide_cpu());
                }
            }
        }
    }

    public void getIdeRam() {
        for (Processo processo : processoList) {
            for (int i = 0; i < nomesIde.size(); i++) {
                if (processo.getNome().equals(nomesIde.get(i))) {
                    processDatas.setUs_ide_ram(processo.getUsoMemoria());
                    super.valoresRamIDE.add(processDatas.getUs_ide_ram());
                }
            }
        }
    }

    public void getIdeDisco() {
        for (Processo processo : processoList) {
            for (int i = 0; i < nomesIde.size(); i++) {
                if (processo.getNome().equals(nomesIde.get(i))) {
                    processDatas.setUs_ide_disco(processo.getMemoriaVirtualUtilizada());
                    super.valoresDiscoIDE.add(processDatas.getUs_ide_disco());
                }
            }
        }
    }

    public void showAll() {
        System.out.println(processDatas.valoresCpuIDE);
        System.out.println(processDatas.valoresDiscoIDE);
        System.out.println(processDatas.valoresNomeIDE);
        System.out.println(processDatas.valoresRamIDE);
//        System.out.println(processDatas.getFk_id_maquina());
    }

//    public void insertIntoValues() throws IOException {
//        processIdeDAO.insertIdeProcess(processDatas);
//    }
    public void insertIdeProcess() throws IOException {
        GerandoLog gerarLog = new GerandoLog();

        for (int i = 0; i < processDatas.getValoresNomeIDE().size(); i++) {
            Long disco = processDatas.getValoresDiscoIDE().get(i);
            String nomeIDE = processDatas.getValoresNomeIDE().get(i);
            Double ram = processDatas.getValoresRamIDE().get(i);
            Float cpu = processDatas.getValoresCpuIDE().get(i);

//            System.out.println(String.format("\n Sabendo o resto: \n"
//                    + "nome da IDE: %s \n"
//                    + "Ram: %s \n"
//                    + "CPU: %s \n"
//                    + "Disco: %s \n"
//                    + "Fk id da maquina: %s", nomeIDE, ram, cpu, disco, allIdeDates.getFk_id_maquina()));
//
            String insertProcessValues = "INSERT INTO tb_processos_ide (us_dt_hr_start_IDE, us_dt_hr_end_IDE, us_ide_nome_processo, us_ide_ram, us_ide_cpu, us_ide_disco, fk_id_maquina) VALUES (GETDATE(), GETDATE(), ? , ? , ?, ?, ?)";
            template.update(insertProcessValues, nomeIDE, ram, cpu, disco, super.fk_id_maquina);

            System.out.println(String.format("\n Inserindo no banco: \n"
                    + "nome da IDE: %s \n"
                    + "Ram: %s \n"
                    + "CPU: %s \n"
                    + "Disco: %b \n"
                    + "Fk id da maquina: %s", nomeIDE, ram, cpu, disco));

        }

        try {
            gerarLog.gravarLog("\n inserindo dados de maquina");

        } catch (IOException e) {
            gerarLog.gravarLog(String.format("%s", e));

        }
    }

}
