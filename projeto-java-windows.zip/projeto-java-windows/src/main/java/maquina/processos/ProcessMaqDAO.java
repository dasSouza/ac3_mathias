package maquina.processos;

import SlackConnection.Slack;
import java.io.IOException;
import org.json.JSONObject;
import org.springframework.jdbc.core.JdbcTemplate;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import jdbc.Conexao;
import log.GerandoLog;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import usuario.Usuario;

public class ProcessMaqDAO extends MaquinaDatas {

//    Conection conection = new Conection();
    Conexao con = new Conexao();
    JdbcTemplate template = new JdbcTemplate(con.getBanco());

    public ProcessMaqDAO(Usuario user) {
        super(user);
    }

//    public void maquinaProcess(MaquinaDatas maquinaDatas, Usuario user) throws IOException {
//        GerandoLog gerarLog = new GerandoLog();
//
//        List<MaquinaDatas> pesquisandoMaquina = template.query("SELECT * from tb_us_maquina where fk_id_funcionario = ?",
//                new BeanPropertyRowMapper<>(MaquinaDatas.class), user.getId_cpf());
//
//        if (pesquisandoMaquina.isEmpty()) {
//
//            String insertProcessValues = "insert into tb_us_maquina values (?, ?, ?, ?, ?)";
//
//            template.update(insertProcessValues, maquinaDatas.getUs_name_maquina(), maquinaDatas.getUs_vl_ram_total(), maquinaDatas.getUs_vl_disco_total(), maquinaDatas.getUs_vl_cpu_total(), maquinaDatas.getFk_id_funcionario());
////            template.query(insertProcessValues, maquinaDatas.getUs_name_maquina(), maquinaDatas.getUs_vl_ram_total(), maquinaDatas.getUs_vl_disco_total(), maquinaDatas.getUs_vl_cpu_total(), super.getId_cpf());
//
//            System.out.println("Inserindo dados no banco de dados: " + maquinaDatas);
//
//        }
//
////        Parte do SLACK
////        Integer us_cpu = 15;
////
////        if(us_cpu != 90.0){
////            Slack slack = new Slack();
////            JSONObject json = new JSONObject();
////
////            json.put("text", "------Alerta Vermelho------" +"Uso CPU:" +us_cpu + "\n Data: " + LocalDate.now() + "\n Hora: "+ LocalTime.now());
////
////            try {
////                slack.sendMessage(json);
////            } catch (Exception e) {
////                e.printStackTrace();
////            }
//        try {
//            gerarLog.gravarLog("\n inserindo dados de maquina");
//
//        } catch (IOException e) {
//            gerarLog.gravarLog(String.format("%s", e));
//
//        }
//    }
}
