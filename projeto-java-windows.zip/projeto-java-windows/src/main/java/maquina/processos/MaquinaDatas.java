package maquina.processos;

import usuario.Usuario;

public class MaquinaDatas extends Usuario {

    private Integer id_maquina;
    private String us_name_maquina;
    private Long us_vl_ram_total;
    private String us_vl_cpu_total;
    private Long us_vl_disco_total;
    private Long fk_id_funcionario;

    public MaquinaDatas(Usuario user) {
        this.us_name_maquina = "";
        this.us_vl_ram_total = 0453443534L;
        this.us_vl_cpu_total = "";
        this.us_vl_disco_total = 0453443534L;
        this.fk_id_funcionario = super.getId_cpf();
    }

    public Integer getId_maquina() {
        return id_maquina;
    }

    public void setId_maquina(Integer id_maquina) {
        this.id_maquina = id_maquina;
    }

    public String getUs_name_maquina() {
        return us_name_maquina;
    }

    public void setUs_name_maquina(String us_name_maquina) {
        this.us_name_maquina = us_name_maquina;
    }

    public Long getUs_vl_ram_total() {
        return us_vl_ram_total / 1000000000l;
    }

    public void setUs_vl_ram_total(Long us_vl_ram_total) {
        this.us_vl_ram_total = us_vl_ram_total;
    }

    public String getUs_vl_cpu_total() {
        return us_vl_cpu_total;
    }

    public void setUs_vl_cpu_total(String us_vl_cpu_total) {
        this.us_vl_cpu_total = us_vl_cpu_total;
    }

    public Long getUs_vl_disco_total() {
        return us_vl_disco_total / 1024l / 1024l / 1024l;
    }

    public void setUs_vl_disco_total(Long us_vl_disco_total) {
        this.us_vl_disco_total = us_vl_disco_total;
    }

    public Long getFk_id_funcionario() {
        return fk_id_funcionario;
    }

    public void setFk_id_funcionario(Long fk_id_funcionario) {
        this.fk_id_funcionario = fk_id_funcionario;
    }

    @Override
    public String toString() {
        return String.format("nome %s "
                + "ram = %d "
                + "cpu = %s "
                + "disco = %d",
                getUs_name_maquina(),
                getUs_vl_ram_total(),
                getUs_vl_cpu_total(),
                getUs_vl_disco_total());
    }

}
