package maquina.processos;

import usuario.Usuario;
import com.github.britooo.looca.api.core.Looca;
import com.github.britooo.looca.api.group.discos.DiscosGroup;
import com.github.britooo.looca.api.group.memoria.Memoria;
import com.github.britooo.looca.api.group.processador.Processador;
import usuario.Usuario;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Logger;
import javax.xml.transform.Templates;
import jdbc.Conexao;
import log.GerandoLog;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

public class GetAllProcess extends MaquinaDatas {

    MaquinaDatas maquina = new MaquinaDatas(user);
    Looca looca = new Looca();
    Processador processador = looca.getProcessador();
    DiscosGroup discosGroup = new DiscosGroup();
    Memoria memoria = new Memoria();

    public GetAllProcess(Usuario user) {
        super(user);
    }

    /**
     *
     * @param usuario
     */
    public void memoriaTotal() {
        super.setUs_vl_ram_total(memoria.getTotal());
    }

//    public void usoMemoriaAtual() {
//        maquina.setUs_memoria_atual(memoria.getEmUso().doubleValue());
//    }
//    public void memoriaDisponivel() {
//        Memoria memoria = new Memoria();
//        maquina.setUs_ram_disponivel(memoria.getTotal().doubleValue());
//        maquina.setUs_ram_disponivel(ramTotal.doubleValue());
//    }
    public void getDiscoTotal() {
        super.setUs_vl_disco_total(discosGroup.getTamanhoTotal());
        System.out.println("\n Atribuindo dados de disco: " + discosGroup.getTamanhoTotal() / 1024 / 1024 / 1024);
    }

    public void getCpuNome() {
        super.setUs_vl_cpu_total(processador.getNome());
        System.out.println("\n Atribuindo dados de nome de Cpu(processador): " + processador.getNome());
    }

    public void getNamePc() {
        try {
            super.setUs_name_maquina(InetAddress.getLocalHost().getHostName());
            System.out.println(" \n Atribuindo nome da maquina: " + InetAddress.getLocalHost().getHostName());
        } catch (Exception e) {
            System.out.println("Exception caught = " + e.getMessage());
        }
//        maquina.setUs_name_pc(System.getProperty("user.name"));
//        System.out.println("Atribuindo nome da maquina: " + maquina.getUs_name_pc()); // perguntar pro prof sobre
    }

    public void insertDatesMaquina(Usuario user) throws IOException {
//        maqDAO.maquinaProcess(maqDAO, user);

        maquinaProcess(maqDAO, user);

        System.out.println("\n Inserindo dados de Maquina " + super.toString());
        GerandoLog gerarLog = new GerandoLog();

        try {
            gerarLog.gravarLog("\n inserindo dados de maquina");

        } catch (IOException e) {
            gerarLog.gravarLog(String.format("%s", e));

        }
    }

    public void maquinaProcess(MaquinaDatas maquinaDatas, Usuario user) throws IOException {
        Conexao con = new Conexao();
        JdbcTemplate template = new JdbcTemplate(con.getBanco());
        
        Integer contador = 0;
        
        GerandoLog gerarLog = new GerandoLog();

        List<MaquinaDatas> pesquisandoMaquina = template.query("SELECT * from tb_us_maquina where fk_id_funcionario = ?",
                new BeanPropertyRowMapper<>(MaquinaDatas.class), user.getId_cpf());

        for (MaquinaDatas maquinaDatas1 : pesquisandoMaquina) {
            
        }
        
        if (pesquisandoMaquina.isEmpty()) {

            String insertProcessValues = "insert into tb_us_maquina values (?, ?, ?, ?, ?)";

            template.update(insertProcessValues, maquinaDatas.getUs_name_maquina(), maquinaDatas.getUs_vl_ram_total(), maquinaDatas.getUs_vl_disco_total(), maquinaDatas.getUs_vl_cpu_total(), maquinaDatas.getFk_id_funcionario());
//            template.query(insertProcessValues, maquinaDatas.getUs_name_maquina(), maquinaDatas.getUs_vl_ram_total(), maquinaDatas.getUs_vl_disco_total(), maquinaDatas.getUs_vl_cpu_total(), super.getId_cpf());

            System.out.println("Inserindo dados no banco de dados: " + maquinaDatas);

        }

//        Parte do SLACK
//        Integer us_cpu = 15;
//
//        if(us_cpu != 90.0){
//            Slack slack = new Slack();
//            JSONObject json = new JSONObject();
//
//            json.put("text", "------Alerta Vermelho------" +"Uso CPU:" +us_cpu + "\n Data: " + LocalDate.now() + "\n Hora: "+ LocalTime.now());
//
//            try {
//                slack.sendMessage(json);
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
        try {
            gerarLog.gravarLog("\n inserindo dados de maquina");

        } catch (IOException e) {
            gerarLog.gravarLog(String.format("%s", e));

        }
    }

//    public MaquinaDatas atribuindoValores() {
//
//        Conexao con = new Conexao();
//
//        JdbcTemplate template = new JdbcTemplate(con.getBanco());
//
//        List<MaquinaDatas> pegandoTudoMaquina = template.query("SELECT * FROM tb_us_maquina where fk_id_funcionario = ?",
//                new BeanPropertyRowMapper<>(MaquinaDatas.class), super.getFk_id_funcionario());
//
//        MaquinaDatas objMaq = new MaquinaDatas(super.getFk_id_funcionario());
//
//        for (Iterator<MaquinaDatas> iterator = pegandoTudoMaquina.iterator(); iterator.hasNext();) {
//            MaquinaDatas proximo = iterator.next();
//
//            objMaq.setId_maquina(proximo.getId_maquina());
//            objMaq.setUs_name_maquina(proximo.getUs_name_maquina());
//            objMaq.setUs_vl_ram_total(proximo.getUs_vl_ram_total());
//            objMaq.setUs_vl_disco_total(proximo.getUs_vl_disco_total());
//            objMaq.setUs_vl_cpu_total(proximo.getUs_vl_cpu_total());
//            objMaq.setFk_id_funcionario(proximo.getFk_id_funcionario());
//
//        }
//
//        return objMaq;
//    }
}
