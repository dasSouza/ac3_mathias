package empresa;

public class Empresa {

    private Integer id_comp;
    protected String kc_nome_comp;
    private Integer kc_cep_comp;
    private Integer kc_cnpj_comp;
    private Integer kc_telefone_comp;
    private String kc_email_comp;

    public Empresa() {
        this.id_comp = 0;
        this.kc_nome_comp = "";
        this.kc_cep_comp = 0;
        this.kc_cnpj_comp = 0;
        this.kc_telefone_comp = 0;
        this.kc_email_comp = "";
    }

    public Integer getId_comp() {
        return id_comp;
    }

    public void setId_comp(Integer id_comp) {
        this.id_comp = id_comp;
    }

    public String getKc_nome_comp() {
        return kc_nome_comp;
    }

    public void setKc_nome_comp(String kc_nome_comp) {
        this.kc_nome_comp = kc_nome_comp;
    }

    public Integer getKc_cep_comp() {
        return kc_cep_comp;
    }

    public void setKc_cep_comp(Integer kc_cep_comp) {
        this.kc_cep_comp = kc_cep_comp;
    }

    public Integer getKc_cnpj_comp() {
        return kc_cnpj_comp;
    }

    public void setKc_cnpj_comp(Integer kc_cnpj_comp) {
        this.kc_cnpj_comp = kc_cnpj_comp;
    }

    public Integer getKc_telefone_comp() {
        return kc_telefone_comp;
    }

    public void setKc_telefone_comp(Integer kc_telefone_comp) {
        this.kc_telefone_comp = kc_telefone_comp;
    }

    public String getKc_email_comp() {
        return kc_email_comp;
    }

    public void setKc_email_comp(String kc_email_comp) {
        this.kc_email_comp = kc_email_comp;
    }
}
